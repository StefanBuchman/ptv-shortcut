import json
from hashlib import sha1
import hmac
import binascii
import os
import haversine as hs
import requests
from datetime import datetime
from dateutil import tz
from dateutil import parser

stop = {
    'McKinnon' : {
        'name': 'McKinnon',
        'id' : 1119,
        'latitude' : -37.910305,
        'longitude' : 145.0383,
        'direction' : 1,
        'route': 6
    },
    'Flinders' : {
        'name': 'Flinders',
        'id' : 1071,
        'latitude' : -37.81831,
        'longitude' : 144.966965,
        'direction' : 5,
        'route': 6
    },
    'Elsternwick' : {
        'name': 'Elsternwick',
        'id' : 1061,
        'latitude' : -37.88475,
        'longitude' : 145.0009,
        'direction' : 1,
        'route': 12
    }
}

routeType = {
    'train': 0
}

def getURL(request):
    devId = os.environ['id']
    key = os.environ['key']
    endpoint = os.environ['endpoint']
    
    request = request + ('&' if ('?' in request) else '?')
    raw = request+'devid={0}'.format(devId)
    
    # Encode the string
    key_bytes = bytes(key, 'latin-1')
    data_bytes = bytes(raw, 'latin-1')
    
    hashed = hmac.new(key_bytes, data_bytes, sha1)
    signature = hashed.hexdigest()
    
    return 'https://'+endpoint+raw+'&signature={1}'.format(devId, signature)

def callPTV(apiURL):
    
    response = requests.get(apiURL)
    
    if response.status_code == 200:
        ptvJSON = response.json()
        return ptvJSON
    else:
        return
    
def getClosestStop(lat, lon):

    closestStop = stop['McKinnon']
    closestStopDistance = hs.haversine((lat, lon), (closestStop['latitude'], closestStop['longitude']))

    for stop in stop:
        stopDistance = hs.haversine((lat, lon), (stop['latitude'], stop['longitude']))
        if stopDistance < closestStopDistance:
            closestStop = stop
            closestStopDistance = stopDistance

    print('The closest stop is {0}'.format(closestStop['name']))

    return closestStop

def lambda_handler(event, context):
    
    log = os.environ['log']
    
    if log == "high":
        print(event)
    
    myLat = event.headers['location-lat']
    myLong = event.headers['location-long']

    closestStop = getClosestStop(myLat, myLong)
    
    ptvRequest = '/v3/departures/route_type/{routeType}/stop/{stop}'\
        '/route/{route}?direction_id={direction}&max_results=1&'\
        'include_cancelled=false'.format(routeType = routeType['train'], stop = closestStop['name'], 
        route = closestStop['route'], direction = closestStop['direction'])
    
    ptvURL = getURL(ptvRequest)
    ptvData = callPTV(ptvURL)

    if log == "high":
        print(ptvData)
    
    nextDepartureUTC = ptvData['departures'][0]['estimated_departure_utc']
    nextDeparture = parser.parse(nextDepartureUTC)
    
    to_zone = tz.gettz('Australia/Melbourne')
    nextDepartureMEL = nextDeparture.astimezone(to_zone)
    
    tz_info = nextDepartureMEL.tzinfo
    dtNow = datetime.now(tz_info)
    
    deltaTime = nextDepartureMEL - dtNow
    
    seconds = deltaTime.total_seconds()
    mins = round(seconds / 60)
    
    #message = 'The next train is departing at {0} {1} {2} in {3} minutes'.format(
    #    nextDepartureMEL.strftime("%-I"), nextDepartureMEL.strftime("%M"), nextDepartureMEL.strftime("%p"), mins)
        
    message = 'The next train is departing at {0} in {1} minutes'.format(nextDepartureMEL.strftime("%-I:%M %p"), mins)
    
    return {
        'statusCode': 200,
        'body': message
    }